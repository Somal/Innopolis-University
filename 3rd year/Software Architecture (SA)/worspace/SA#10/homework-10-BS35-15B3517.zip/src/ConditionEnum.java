/**
 * Created by somal on 28.03.16.
 */
public enum ConditionEnum {On,Off
}
