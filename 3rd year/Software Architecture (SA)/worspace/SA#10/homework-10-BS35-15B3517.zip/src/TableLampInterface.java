/**
 * Created by somal on 28.03.16.
 */
public interface TableLampInterface {

    public void On();

    public void Off();

    public ConditionInterface getCondition();
}
