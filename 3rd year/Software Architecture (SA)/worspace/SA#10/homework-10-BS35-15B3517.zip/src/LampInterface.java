/**
 * Created by somal on 28.03.16.
 */
public interface LampInterface {

    public void On();

    public void Off();

    public ConditionInterface getCondition();
}
