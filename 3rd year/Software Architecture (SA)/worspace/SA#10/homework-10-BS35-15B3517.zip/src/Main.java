/**
 * Created by somal on 28.03.16.
 */
public class Main {
    public static void main(String[] args) {
        TableLamp tableLamp=new TableLamp(new Switch(new Condition()),new Lamp(new Condition()));

    }
}
