/**
 * Created by somal on 28.03.16.
 */
public interface SwitchInterface {

    public void On();

    public void Off();

    public ConditionInterface getCondition();

}
