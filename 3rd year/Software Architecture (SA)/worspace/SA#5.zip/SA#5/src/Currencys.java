/**
 * Created by somal on 21.02.16.
 */
public enum Currencys { DOLLAR, EURO
}
