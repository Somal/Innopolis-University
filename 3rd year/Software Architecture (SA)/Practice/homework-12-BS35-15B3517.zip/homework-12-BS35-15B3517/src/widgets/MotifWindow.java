package widgets;

public class MotifWindow extends Window {
	public MotifWindow(){
		System.out.println("new instance of class MotifWindow");
	}
}
