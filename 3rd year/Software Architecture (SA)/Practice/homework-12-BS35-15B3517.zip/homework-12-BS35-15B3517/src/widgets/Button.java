package widgets;

public class Button {
    public Button(){
        System.out.println("new instance of class Button");
    }
}