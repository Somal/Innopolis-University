package widgets;

public class PMButton extends Button {
    public PMButton(){
        System.out.println("new instance of class PMWButton");
    }
}
