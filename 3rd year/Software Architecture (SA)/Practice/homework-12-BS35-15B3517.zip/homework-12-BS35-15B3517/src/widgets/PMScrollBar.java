package widgets;

public class PMScrollBar extends ScrollBar {
	public PMScrollBar(){
		System.out.println("new instance of class PMScrollBar");
	}
	
	public String toString() {
		return "printing new instance of class PMScrollBar";
	}
}
