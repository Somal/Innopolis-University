package widgets;

public class Window {
	public Window(){
		System.out.println("new instance of class Window");
	}
}
