package widgets;

public class MotifButton extends Button {
    public MotifButton(){
        System.out.println("new instance of class MotifButton");
    }
}
