package widgets;

public class MotifScrollBar extends ScrollBar {
	public MotifScrollBar(){
		System.out.println("new instance of class MotifScrollBar");
	}
	
	public String toString() {
		return "printing new instance of class MotifScrollBar";
	}
	
}
