package widgets;

public class PMWindow extends Window {
	public PMWindow(){
		System.out.println("new instance of class PMWindow");
	}
}
