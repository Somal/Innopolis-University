package widgets;

public class ScrollBar {
	public ScrollBar(){
		System.out.println("new instance of class ScrollBar");
	}
}
