CREATE TABLE "books" (
	"isbn" integer NOT NULL,
	"title" text NOT NULL,
	"author_id" integer,
	"subject_id" integer,
	Constraint "books_id_pkey" Primary Key ("isbn")
);

CREATE TABLE "authors" (
	"id" integer NOT NULL,
	"last_name" text,
	"first_name" text,
	Constraint "authors_pkey" Primary Key ("id")
);

CREATE TABLE "publishers" (
	"id" integer NOT NULL,
	"name" text,
	"address" text,
	Constraint "publishers_pkey" Primary Key ("id")
);

CREATE TABLE "publishes" (
	"book_id" integer,
	"publisher_id" integer,
	 Constraint "publishes_pkey" Primary Key ("book_id", "publisher_id")
);

CREATE TABLE "copies" (
	"isbn" integer,
	"copy_id" integer,
	"shelf_no" integer,
	"position" integer,
	 Constraint "copies_pkey" Primary Key ("isbn", "copy_id")
);


CREATE TABLE "readers" (
	"id" integer NOT NULL,
	"last_name" text,
	"first_name" text,
	Constraint "readers_pkey" Primary Key ("id")
);

CREATE TABLE "borrow" (
	"isbn" integer NOT NULL,
	"copy_id" integer  NOT NULL,
	"reader_id" integer  NOT NULL,
	"return_date" date,
	Constraint "borrow_pkey" Primary Key ("isbn", "copy_id", "reader_id")
);


-- -publishers-----
insert into publishers values(150, 'Kids Can Press', 'Kids Can Press, 29 Birch Ave. Toronto, ON  M4V 1E2');
insert into publishers values(91, 'Henry Holt & Company, Inc.', 'Henry Holt & Company, Inc. 115 West 18th Street New York, NY 10011');
insert into publishers values(113, 'O''Reilly & Associates', 'O''Reilly & Associates, Inc. 101 Morris St, Sebastopol, CA 95472');
insert into publishers values(62, 'Watson-Guptill Publications', '1515 Boradway, New York, NY 10036');
insert into publishers values(105, 'Noonday Press', 'Farrar Straus & Giroux Inc, 19 Union Square W, New York, NY 10003');
insert into publishers values(99, 'Ace Books', 'The Berkley Publishing Group, Penguin Putnam Inc, 375 Hudson St, New York, NY 10014');
insert into publishers values(101, 'Roc	Penguin', 'Putnam Inc, 375 Hudson St, New York, NY 10014');
insert into publishers values(163, 'Mojo Press', 'Mojo Press, PO Box 1215, Dripping Springs, TX 78720');
insert into publishers values(171, 'Books of Wonder', 'Books of Wonder, 16 W. 18th St. New York, NY, 10011');
insert into publishers values(102, 'Penguin', 'Penguin Putnam Inc, 375 Hudson St, New York, NY 10014');
insert into publishers values(75, 'Doubleday', 'Random House, Inc, 1540 Broadway, New York, NY 10036');
insert into publishers values(65, 'HarperCollins', 'HarperCollins Publishers, 10 E 53rd St, New York, NY 10022');
insert into publishers values(59, 'Random House', 'Random House, Inc, 1540 Broadway, New York, NY 10036');

-- -------------authors---------------
insert into authors values ( 1111, 'Denham', 'Ariel');
insert into authors values ( 1212, 'Worsley', 'John');
insert into authors values ( 15990, 'Bourgeois', 'Paulette');
insert into authors values ( 25041, 'Bianco Margery', 'Williams');
insert into authors values ( 16, 'Alcott	Louisa', 'May');
insert into authors values ( 4156, 'King', 'Stephen');
insert into authors values ( 1866, 'Herbert', 'Frank');
insert into authors values ( 1644, 'Hogarth', 'Burne');
insert into authors values ( 2031, 'Brown', 'Margaret Wise');
insert into authors values ( 115, 'Poe Edgar', 'Allen');
insert into authors values ( 7805, 'Lutz', 'Mark');
insert into authors values ( 7806, 'Christiansen', 'Tom');
insert into authors values ( 1533, 'Brautigan', 'Richard');
insert into authors values ( 1717, 'Brite', 'Poppy Z.');
insert into authors values ( 2112, 'Gorey', 'Edward');
insert into authors values ( 2001, 'Clarke', 'Arthur C.');
insert into authors values ( 1213, 'Brookins', 'Andrew');
insert into authors values ( 1809, 'David', 'Sidler');


-- ---books----------------------
insert into books values ( 7808, 'The Shining',	4156,	9);
insert into books values ( 4513, 'Dune',	1866,	15);
insert into books values ( 4267, '2001: A Space Odyssey',	2001,	15);
insert into books values ( 1608, 'The Cat in the Hat',	1809,	2);
insert into books values ( 1590, 'Bartholomew and the Oobleck',	1809,	2);
insert into books values ( 25908, 'Franklin in the Dark',	15990,	2);
insert into books values ( 1501, 'Goodnight Moon',	2031,	2);
insert into books values ( 190, 'Little Women',	16,	6);
insert into books values ( 1234, 'The Velveteen Rabbit',	25041,	3);
insert into books values ( 2038, 'Dynamic Anatomy',	1644,	0);
insert into books values ( 156, 'The Tell-Tale Heart',	115,	9);
insert into books values ( 41473, 'Programming Python',	7805,	4);
insert into books values ( 41477, 'Learning Python',	7805,	4);
insert into books values ( 41478, 'Perl Cookbook',	7806,	4);
insert into books values ( 41472, 'Practical PostgreSQL',	1212,	4);


-- -------publishes-------------------
insert into publishes values ( 156,	163 );
insert into publishes values ( 156,	171 );
insert into publishes values ( 190,	91 );
insert into publishes values ( 1234,	102 );
insert into publishes values ( 1501,	65 );
insert into publishes values ( 1590,	59 );
insert into publishes values ( 1608,	59 );
insert into publishes values ( 2038,	62 );
insert into publishes values ( 4267,	101 );
insert into publishes values ( 4513,	99 );
insert into publishes values ( 7808,	75 );
insert into publishes values ( 25908,	150 );
insert into publishes values ( 41473,	113 );


-- ----------------copies--------------

insert into copies values ( 	156	,	1	,	1	,	1	);
insert into copies values ( 	156	,	2	,	2	,	1	);
insert into copies values ( 	190	,	1	,	1	,	2	);
insert into copies values ( 	1234	,	1	,	1	,	3	);
insert into copies values ( 	1234	,	2	,	1	,	4	);
insert into copies values ( 	1234	,	3	,	1	,	5	);
insert into copies values ( 	1501	,	1	,	2	,	2	);
insert into copies values ( 	1590	,	1	,	2	,	3	);
insert into copies values ( 	1608	,	1	,	2	,	4	);
insert into copies values ( 	1608	,	2	,	2	,	5	);
insert into copies values ( 	1608	,	3	,	3	,	1	);
insert into copies values ( 	1608	,	4	,	3	,	2	);
insert into copies values ( 	1608	,	5	,	3	,	3	);
insert into copies values ( 	2038	,	1	,	3	,	4	);
insert into copies values ( 	4267	,	1	,	3	,	5	);
insert into copies values ( 	4513	,	1	,	4	,	1	);
insert into copies values ( 	7808	,	1	,	4	,	2	);
insert into copies values ( 	25908	,	1	,	4	,	3	);
insert into copies values ( 	41472	,	1	,	4	,	5	);
insert into copies values ( 	41472	,	2	,	5	,	1	);
insert into copies values ( 	41473	,	1	,	5	,	2	);
insert into copies values ( 	41477	,	1	,	5	,	3	);
insert into copies values ( 	41477	,	2	,	5	,	4	);
insert into copies values ( 	41477	,	3	,	5	,	5	);
insert into copies values ( 	41477	,	4	,	5	,	6	);
insert into copies values ( 	41478	,	1	,	5	,	7	);


-- -------------------customers---------------

insert into readers values ( 	107	,	'Jackson'	,	'Annie'	);
insert into readers values ( 	112	,	'Gould'	,	'Ed'	);
insert into readers values ( 	142	,	'Allen'	,	'Chad'	);
insert into readers values ( 	146	,	'Williams'	,	'James'	);
insert into readers values ( 	172	,	'Brown'	,	'Richard'	);
insert into readers values ( 	185	,	'Morrill'	,	'Eric'	);
insert into readers values ( 	221	,	'King'	,	'Jenny'	);
insert into readers values ( 	270	,	'Bollman'	,	'Julie'	);
insert into readers values ( 	388	,	'Morrill'	,	'Royce'	);
insert into readers values ( 	409	,	'Holloway'	,	'Christine'	);
insert into readers values ( 	430	,	'Black'	,	'Jean'	);
insert into readers values ( 	476	,	'Clark'	,	'James'	);
insert into readers values ( 	480	,	'Thomas'	,	'Rich'	);
insert into readers values ( 	488	,	'Young'	,	'Trevor'	);
insert into readers values ( 	574	,	'Bennett'	,	'Laura'	);
insert into readers values ( 	652	,	'Anderson'	,	'Jonathan'	);
insert into readers values ( 	655	,	'Olson'	,	'Dave'	);
insert into readers values ( 	671	,	'Brown'	,	'Chuck'	);
insert into readers values ( 	723	,	'Eisele'	,	'Don'	);
insert into readers values ( 	724	,	'Holloway'	,	'Adam'	);
insert into readers values ( 	738	,	'Gould'	,	'Shirley'	);
insert into readers values ( 	830	,	'Robertson'	,	'Royce'	);
insert into readers values ( 	853	,	'Black'	,	'Wendy'	);
insert into readers values ( 	860	,	'Owens'	,	'Tim'	);
insert into readers values ( 	880	,	'Robinson'	,	'Tammy'	);
insert into readers values ( 	898	,	'Gerdes'	,	'Kate'	);
insert into readers values ( 	964	,	'Gould'	,	'Ramon'	);
insert into readers values ( 	1045	,	'Owens'	,	'Jean'	);
insert into readers values ( 	1125	,	'Bollman'	,	'Owen'	);
insert into readers values ( 	1149	,	'Becker'	,	'Owen'	);
insert into readers values ( 	1123	,	'Corner'	,	'Kathy'	);


-- ---------------------borrow--------------------
insert into borrow values ( 	156	,	1	,	388	,	'2015-03-08'	);
insert into borrow values ( 	41478	,	1	,	671	,	'2015-03-10'	);
insert into borrow values ( 	41477	,	3	,	388	,	'2015-03-17'	);
insert into borrow values ( 	25908	,	1	,	1149	,	'2015-04-18'	);
insert into borrow values ( 	1608	,	1	,	1045	,	'2015-03-20'	);
insert into borrow values ( 	1608	,	3	,	388	,	'2015-03-08'	);
insert into borrow values ( 	1608	,	5	,	652	,	'2015-05-08'	);
insert into borrow values ( 	1234	,	3	,	185	,	'2015-03-01'	);
insert into borrow values ( 	7808	,	1	,	723	,	'2015-03-04'	);









